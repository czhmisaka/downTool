import threading
import os
import json
import time



class threadGuiHelper:
    '''
    threadPoolTool附属图形化显示工具
    '''
    def __init__(self):
        '''
        用于展示多线程操作工作状态的附属库
            目前考虑使用pygame实现
        变量说明
            
        '''
        
        
    def start(self):        
        print(1)